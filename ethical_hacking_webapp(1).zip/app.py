from flask import Flask, render_template, request, redirect, session, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Sample hashed admin password (password is 'admin123')
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD_HASH = generate_password_hash('admin123')

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, password):
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))


from tor_utils import *
from modules.sqli_scanner import sqli_bp
from modules.xss_injector import xss_bp
from modules.nmap_scanner import nmap_bp
from modules.lfi_rfi_scanner import lfi_bp
from modules.cms_detector import cms_bp
from modules.subdomain_enum import sub_bp
from modules.brute_forcer import bf_bp
from modules.ddos_test import ddos_bp
from modules.terminal import term_bp

app.register_blueprint(sqli_bp)
app.register_blueprint(xss_bp)
app.register_blueprint(nmap_bp)
app.register_blueprint(lfi_bp)
app.register_blueprint(cms_bp)
app.register_blueprint(sub_bp)
app.register_blueprint(bf_bp)
app.register_blueprint(ddos_bp)
app.register_blueprint(term_bp)


if __name__ == '__main__':
    app.run(debug=True)