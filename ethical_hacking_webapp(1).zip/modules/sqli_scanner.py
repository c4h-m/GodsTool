from flask import Blueprint, request, render_template
import tor_utils
import re

sqli_bp = Blueprint('sqli', __name__, template_folder='templates')

payloads = ["' OR '1'='1", "" OR "1"="1", "'; sleep(5)--"]

@sqli_bp.route('/sqli', methods=['GET', 'POST'])
def sqli():
    result = None
    if request.method == 'POST':
        url = request.form.get('url')
        for payload in payloads:
            test_url = url + payload
            resp = tor_utils.safe_get(test_url)
            if re.search(r"SQL syntax", resp, re.IGNORECASE) or "Error" in resp:
                result = f"Potential SQLi with payload: {payload}"
                break
        if not result:
            result = "No SQLi detected."
    return render_template('sqli.html', result=result)