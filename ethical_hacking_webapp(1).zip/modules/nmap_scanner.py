from flask import Blueprint, request, render_template
import tor_utils
import nmap

nmap_bp = Blueprint('nmap', __name__, template_folder='templates')

@nmap_bp.route('/nmap', methods=['GET', 'POST'])
def nmap_scan():
    result = None
    if request.method == 'POST':
        target = request.form.get('target')
        nm = nmap.PortScanner()
        nm.scan(hosts=target, arguments='-Pn -sS')
        result = nm[target].all_protocols()
    return render_template('nmap.html', result=result)