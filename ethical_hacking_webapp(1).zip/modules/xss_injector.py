from flask import Blueprint, request, render_template
import tor_utils

xss_bp = Blueprint('xss', __name__, template_folder='templates')
payload = "<script>alert('XSS')</script>"

@xss_bp.route('/xss', methods=['GET', 'POST'])
def xss():
    result = None
    if request.method == 'POST':
        url = request.form.get('url')
        test_url = url + "?q=" + payload
        resp = tor_utils.safe_get(test_url)
        if payload in resp:
            result = "Vulnerable to XSS"
        else:
            result = "No XSS detected"
    return render_template('xss.html', result=result)