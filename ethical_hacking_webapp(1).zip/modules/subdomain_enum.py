from flask import Blueprint, request, render_template
import tor_utils
import re

sub_bp = Blueprint('subdomain', __name__, template_folder='templates')

@sub_bp.route('/subdomains', methods=['GET', 'POST'])
def subdomains():
    result = []
    if request.method == 'POST':
        domain = request.form.get('domain')
        data = tor_utils.safe_get(f"https://crt.sh/?q=%25.{domain}&output=json")
        candidates = re.findall(r'"name_value":"([^"]+)"', data)
        result = sorted(set(candidates))
    return render_template('subdomains.html', result=result)