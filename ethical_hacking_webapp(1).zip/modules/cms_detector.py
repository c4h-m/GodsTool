from flask import Blueprint, request, render_template
import tor_utils

cms_bp = Blueprint('cms', __name__, template_folder='templates')
signatures = {
    "WordPress": "wp-content",
    "Joomla": "Joomla!",
    "Drupal": "drupal.js"
}

@cms_bp.route('/cms', methods=['GET', 'POST'])
def cms():
    result = []
    if request.method == 'POST':
        url = request.form.get('url')
        resp = tor_utils.safe_get(url)
        for name, sig in signatures.items():
            if sig in resp:
                result.append(name)
    return render_template('cms.html', result=result)