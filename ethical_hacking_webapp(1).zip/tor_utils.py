import requests
from requests.exceptions import RequestException

PROXIES = {
    'http': 'socks5h://127.0.0.1:9050',
    'https': 'socks5h://127.0.0.1:9050'
}

def safe_get(url, **kwargs):
    try:
        resp = requests.get(url, proxies=PROXIES, timeout=15, **kwargs)
        return resp.text
    except RequestException as e:
        return f"Error: {e}"

def safe_post(url, data=None, **kwargs):
    try:
        resp = requests.post(url, data=data, proxies=PROXIES, timeout=15, **kwargs)
        return resp.text
    except RequestException as e:
        return f"Error: {e}"